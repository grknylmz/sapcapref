sap.ui.define(
    ["sap/fe/AppComponent"],
    ac => ac.extend("bookshop.Component", {
        metadata: {
            manifest: "json"
        }
    })
)
